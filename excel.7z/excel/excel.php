<?php

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$excel_file = '12012024 DAILY REPORT KILIMANJARO MP WK02 RD.xlsx';

$spreadsheet = \PhpSpreadsheet\IOFactory::load($excel_file);

echo $writer = new \PhpSpreadsheet\Writer\Csv($spreadsheet);

foreach ($spreadsheet->getSheetNames() as $sheet_name) {

    // 將當前 Sheet 的資料儲存為 CSV 檔
    $csv_file = 'example_' . $sheet_name . '.csv';
    $writer->setSheetIndexByName($sheet_name);
    $writer->save($csv_file);
    echo "{$csv_file} generated.";
}

?>
