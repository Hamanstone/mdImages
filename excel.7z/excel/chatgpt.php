<?php

require 'vendor/autoload.php'; // 引入PhpSpreadsheet库

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

// 载入现有的 Excel 文件
$excelFile = 'C:/Users/pega_user/Downloads/template.xlsx';
$spreadsheet = IOFactory::load($excelFile);

$check_symbol = '☑';
$uncheck_symbol = '☐';

$Monday = "Monday-Senin";
$Thursday = "Thursday-Kamis";

// 获取要编辑的工作表
$sheet = $spreadsheet->getActiveSheet();
$sheet->setCellValue('A1', 'Form Lebur(加 班 申 請 單)');
$sheet->setCellValue('B4', 'LA1401261');
$sheet->setCellValue('C4', 'Stone Sun');
$sheet->setCellValue('D4', 'Support VSB3930');
$sheet->setCellValue('E4', '17.20 - 19.20');

// 从 A1 单元格获取数据
$data = $sheet->getCell('A1')->getValue();
echo "A1 单元格的数据是： $data";

// 在这里执行对工作表的修改，例如插入数据、修改单元格等

// 保存对 Excel 文件的修改
$writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
$writer->save('C:/Users/pega_user/Downloads/2024_new.xlsx');

echo "已编辑的 Excel 文件已保存";
